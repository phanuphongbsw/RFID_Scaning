# ร้านเสื้อผ้า — Flask + MySQL

เว็บขายเสื้อผ้าออนไลน์ สำหรับส่งโปรเจกต์

## คุณสมบัติ

- หน้าแรกแสดงรายการสินค้า
- รายละเอียดสินค้า (รูป, ราคา, คำอธิบาย)
- ตะกร้าสินค้า + คำนวณยอดรวมอัตโนมัติ
- หน้าชำระเงิน + QR Code
- สมัครสมาชิก / เข้าสู่ระบบ
- ประวัติการสั่งซื้อ + ติดตามสถานะ
- แอดมิน: จัดการสินค้า (เพิ่ม/แก้ไข/ลบ/อัปโหลดรูป)
- แอดมิน: จัดการคำสั่งซื้อ + รายงานยอดขายรายวัน/รายเดือน

## โครงสร้างโปรเจกต์

```
shop_shirt/
├── app.py              # แอปหลัก Flask
├── config.py           # การตั้งค่า
├── models.py           # โมเดลฐานข้อมูล
├── requirements.txt
├── schema.sql
├── templates/
│   ├── index.html
│   ├── cart.html
│   ├── checkout.html
│   └── admin/
└── static/
    ├── images/         # รูปสินค้าตัวอย่าง
    └── uploads/        # รูปที่อัปโหลด
```

## การติดตั้ง

### 1. ติดตั้ง MySQL และสร้างฐานข้อมูล

```sql
CREATE DATABASE shop_shirt CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

### 2. ตั้งค่า environment

แก้ไขไฟล์ `.env`:

```
MYSQL_USER=root
MYSQL_PASSWORD=รหัสผ่านของคุณ
MYSQL_DATABASE=shop_shirt
```

### 3. ติดตั้ง dependencies

```bash
pip install -r requirements.txt
```

### 4. สร้างรูปภาพตัวอย่าง

```bash
python create_assets.py
```

### 5. รันเว็บ

```bash
python app.py
```

เปิดเบราว์เซอร์ที่ http://localhost:5000

## การเข้าใช้งาน

| บทบาท | URL | Username | Password |
|-------|-----|----------|----------|
| ลูกค้า | `/login` | สมัครใหม่ได้ | — |
| แอดมิน | `/backoffice/login` | `admin` | `123456` |

แอดมินตั้งค่า PromptPay ได้ที่ **ตั้งค่าชำระเงิน** ใน Backoffice
