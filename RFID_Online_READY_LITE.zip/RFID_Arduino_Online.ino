#include <WiFi.h>
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include <SPI.h>
#include <MFRC522.h>

// ===============================
// RFID
// ===============================
#define SS_PIN 5
#define RST_PIN 22

MFRC522 mfrc522(SS_PIN, RST_PIN);

// ===============================
// Wi-Fiเปลี่นตรงนี้
// ===============================

const char* ssid = "ชื่อwifi";
const char* password = "รหัส";

// ===============================
// Flask Serverเปลี่ยนตรงนี้
// ===============================

// IP ของคอมที่รัน Flask
const char* scanServer =
    "https://YOUR-ONLINE-DOMAIN.onrender.com/api/admin/rfid_scan";

// ===============================
// เชื่อมต่อ Wi-Fi
// ===============================

void connectWiFi() {

    Serial.println();
    Serial.println("Connecting WiFi...");

    WiFi.begin(ssid, password);

    int attempt = 0;

    while (WiFi.status() != WL_CONNECTED && attempt < 30) {

        delay(500);
        Serial.print(".");

        attempt++;
    }

    Serial.println();

    if (WiFi.status() == WL_CONNECTED) {

        Serial.println("WiFi Connected");

        Serial.print("ESP32 IP : ");
        Serial.println(WiFi.localIP());

    } else {

        Serial.println("WiFi connection failed");
    }
}

// ===============================
// SETUP
// ===============================

void setup() {

    Serial.begin(115200);

    delay(1000);

    Serial.println();
    Serial.println("==============================");
    Serial.println(" RFID PRODUCT SCANNER");
    Serial.println("==============================");

    // -------------------------------
    // SPI
    // -------------------------------

    SPI.begin(18, 19, 23, 5);

    // -------------------------------
    // RFID
    // -------------------------------

    mfrc522.PCD_Init();

    Serial.println("RFID Reader Ready");

    // -------------------------------
    // Wi-Fi
    // -------------------------------

    connectWiFi();

    Serial.println();
    Serial.println("Ready...");
}

// ===============================
// LOOP
// ===============================

void loop() {

    // ===============================
    // ตรวจสอบ Wi-Fi
    // ===============================

    if (WiFi.status() != WL_CONNECTED) {

        Serial.println();
        Serial.println("WiFi disconnected");

        connectWiFi();

        delay(1000);

        return;
    }

    // ===============================
    // ตรวจสอบบัตร RFID
    // ===============================

    if (!mfrc522.PICC_IsNewCardPresent()) {
        return;
    }

    if (!mfrc522.PICC_ReadCardSerial()) {
        return;
    }

    // ===============================
    // อ่าน UID
    // ===============================

    String uid = "";

    for (byte i = 0; i < mfrc522.uid.size; i++) {

        if (mfrc522.uid.uidByte[i] < 0x10) {
            uid += "0";
        }

        uid += String(
            mfrc522.uid.uidByte[i],
            HEX
        );
    }

    uid.toUpperCase();

    // ===============================
    // แสดง UID
    // ===============================

    Serial.println();
    Serial.println("------------------------------");

    Serial.print("RFID UID : ");
    Serial.println(uid);

    // ===============================
    // ส่ง UID ไป Flask
    // ===============================

    if (WiFi.status() == WL_CONNECTED) {

        HTTPClient http;
        WiFiClientSecure secureClient;
        secureClient.setInsecure(); // Temporary for initial deployment; replace with certificate pinning for production.

        Serial.print("Sending to : ");
        Serial.println(scanServer);

        if (String(scanServer).startsWith("https://")) {
            http.begin(secureClient, scanServer);
        } else {
            http.begin(scanServer);
        }

        // Timeout 5 วินาที
        http.setTimeout(5000);

        // Header
        http.addHeader(
            "Content-Type",
            "application/json"
        );

        // JSON
        String json =
            "{\"uid\":\"" + uid + "\"}";

        Serial.print("JSON : ");
        Serial.println(json);

        // POST
        int code = http.POST(json);

        Serial.print("HTTP Response : ");
        Serial.println(code);

        // ===============================
        // รับข้อมูลจาก Flask
        // ===============================

        if (code > 0) {

            String response = http.getString();

            Serial.print("Server Response : ");
            Serial.println(response);

        } else {

            Serial.println(
                "ส่งข้อมูลไป Flask ไม่สำเร็จ"
            );

            Serial.print(
                "HTTP Error : "
            );

            Serial.println(
                http.errorToString(code)
            );
        }

        http.end();
    }

    // ===============================
    // หยุดการอ่านบัตร
    // ===============================

    mfrc522.PICC_HaltA();

    mfrc522.PCD_StopCrypto1();

    // ป้องกันอ่านบัตรเดิมซ้ำเร็วเกินไป
    delay(800);
}
