"""One-time migration of the bundled SQLite data into DATABASE_URL.

Run only after DATABASE_URL points to the production PostgreSQL database.
The script skips migration when the target already contains users/products.
"""
import os
import sqlite3
from decimal import Decimal

from sqlalchemy import create_engine, select, func

from models import db, User, Category, Product, SiteSettings, Order, OrderItem, Cart

SQLITE_PATH = os.path.join(os.path.dirname(__file__), "shop_shirt.db")

def normalize_db_url(url: str) -> str:
    if url.startswith("postgres://"):
        return "postgresql://" + url[len("postgres://"):]
    return url

def main():
    url = normalize_db_url(os.getenv("DATABASE_URL", "").strip())
    if not url or not url.startswith("postgresql"):
        raise SystemExit("DATABASE_URL must be a PostgreSQL URL")

    target = create_engine(url)
    db.metadata.create_all(target)

    with target.begin() as conn:
        user_count = conn.execute(select(func.count()).select_from(User.__table__)).scalar_one()
        product_count = conn.execute(select(func.count()).select_from(Product.__table__)).scalar_one()
        if user_count or product_count:
            print("Target database is not empty; migration skipped.")
            return

    src = sqlite3.connect(SQLITE_PATH)
    src.row_factory = sqlite3.Row
    try:
        with target.begin() as conn:
            # Preserve parent/child ordering and IDs so existing RFID/product/order links remain intact.
            tables = [
                (User, "users"),
                (Category, "categories"),
                (Product, "products"),
                (SiteSettings, "site_settings"),
                (Order, "orders"),
                (OrderItem, "order_items"),
                (Cart, "cart"),
            ]
            for model, table_name in tables:
                rows = src.execute(f'SELECT * FROM "{table_name}"').fetchall()
                if not rows:
                    continue
                columns = [c.name for c in model.__table__.columns]
                payload = []
                for row in rows:
                    item = {c: row[c] for c in columns if c in row.keys()}
                    payload.append(item)
                if payload:
                    conn.execute(model.__table__.insert(), payload)
                print(f"Migrated {table_name}: {len(payload)} rows")
    finally:
        src.close()

if __name__ == "__main__":
    main()
