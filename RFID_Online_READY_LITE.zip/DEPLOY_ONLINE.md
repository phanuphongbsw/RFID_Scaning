# Online deployment package

This is a separate online-ready copy. The original ZIP files are not modified.

## Recommended hosting
Render Web Service + PostgreSQL. Render supports Flask with Gunicorn and Python build/start commands. Use the Singapore region for lower latency from Thailand.

Build command:
`pip install -r requirements.txt`

Start command:
`gunicorn app:app`

Required environment variables:
- `DATABASE_URL` = PostgreSQL connection string
- `SECRET_KEY` = long random secret
- `ADMIN_PASSWORD` = initial admin password
- `ADMIN_USERNAME` = admin
- `ADMIN_EMAIL` = admin@shop.com
- `AUTO_INIT_DB` = true

### Existing data
The original SQLite database is included as a migration source/backup. After the PostgreSQL database is created, run:
`python migrate_sqlite_to_postgres.py`

The migration script refuses to overwrite a non-empty target database.

### ESP32 + RC522
The online Arduino sketch keeps the existing RC522 wiring and RFID logic. It changes only the Flask destination to an HTTPS placeholder. After the web service has its final URL, replace:
`https://YOUR-ONLINE-DOMAIN.onrender.com/api/admin/rfid_scan`
with the actual URL and upload the sketch to the ESP32.

The existing API route remains `/api/admin/rfid_scan`.

### Important
The original `.env` is intentionally not included in this deployment copy. Never upload the old `.env` to GitHub because it contains local credentials/settings.

Uploaded files under `static/uploads` and `static/slips` need persistent storage or object storage for long-term production use. The current deployment package does not change the existing UI or business routes to introduce a new storage provider.
