"""สร้างรูปภาพตัวอย่างสำหรับโปรเจกต์"""
import os

from PIL import Image, ImageDraw, ImageFont

IMAGES_DIR = os.path.join(os.path.dirname(__file__), "static", "images")
os.makedirs(IMAGES_DIR, exist_ok=True)
os.makedirs(os.path.join(os.path.dirname(__file__), "static", "uploads"), exist_ok=True)

COLORS = [
    ("#f8fafc", "#64748b", "เสื้อยืด\nสีขาว"),
    ("#dbeafe", "#1d4ed8", "เสื้อโปโล\nสีน้ำเงิน"),
    ("#fef3c7", "#b45309", "เสื้อเชิ้ต\nลายตาราง"),
]


def create_shirt_image(filename, bg_color, text_color, label):
    img = Image.new("RGB", (600, 600), bg_color)
    draw = ImageDraw.Draw(img)

    draw.rounded_rectangle([150, 100, 450, 500], radius=30, fill=text_color, outline=text_color)
    draw.ellipse([200, 80, 280, 160], fill=bg_color)
    draw.ellipse([320, 80, 400, 160], fill=bg_color)

    try:
        font = ImageFont.truetype("arial.ttf", 28)
    except OSError:
        font = ImageFont.load_default()

    lines = label.split("\n")
    y = 520
    for line in lines:
        bbox = draw.textbbox((0, 0), line, font=font)
        x = (600 - (bbox[2] - bbox[0])) // 2
        draw.text((x, y), line, fill=text_color, font=font)
        y += 35

    img.save(os.path.join(IMAGES_DIR, filename), "JPEG", quality=90)
    print(f"Created {filename}")


def create_qr_placeholder():
    img = Image.new("RGB", (300, 300), "white")
    draw = ImageDraw.Draw(img)

    for row in range(15):
        for col in range(15):
            if (row + col) % 2 == 0 or row < 3 or col < 3 or row > 11 or col > 11:
                x, y = col * 20, row * 20
                draw.rectangle([x, y, x + 18, y + 18], fill="black")

    draw.rectangle([10, 10, 70, 70], outline="black", width=3)
    draw.rectangle([220, 10, 280, 70], outline="black", width=3)
    draw.rectangle([10, 220, 70, 280], outline="black", width=3)

    try:
        font = ImageFont.truetype("arial.ttf", 16)
    except OSError:
        font = ImageFont.load_default()
    draw.text((75, 140), "PromptPay", fill="black", font=font)

    img.save(os.path.join(IMAGES_DIR, "qr_payment.png"))
    print("Created qr_payment.png")


if __name__ == "__main__":
    for i, (bg, fg, label) in enumerate(COLORS, 1):
        create_shirt_image(f"shirt{i}.jpg", bg, fg, label)
    create_qr_placeholder()
